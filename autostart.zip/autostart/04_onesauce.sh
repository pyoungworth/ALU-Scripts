#!/bin/bash

list_sdl_joysticks() {
  local devs=$(ls /dev/input/event* | sort -tt -nsk3)
  for dev in $devs; do
    if ! [ -r "$dev" ]; then
      continue
    fi
    if ! udevadm info -n "$dev" | grep -q ID_INPUT_JOYSTICK=1; then
      continue
    fi

    local name=$(cat "/sys$(udevadm info -q path $dev)/device/name")

    echo "device=$dev name=$name"

    if [[ "$name" = "push-key"* ]]; then
      export SDL_JOYSTICK_DEVICE_BLACKLIST="$dev;$SDL_JOYSTICK_DEVICE_BLACKLIST"
    fi
  done
}

# Append `joys` with all /dev/input/event* entries that are joysticks.
# An optional name can be given, in which case only entries with that name are appended.
# Print 'joys=<list of devices>', e.g., 'joys=/dev/input/event3:/dev/input/event4'.
find_sdl_joysticks_with_name() {
  local devs=$(ls /dev/input/event* | sort -tt -nsk3)

  for dev in $devs; do
    if ! [ -r "$dev" ]; then
      continue
    fi
    if ! udevadm info -n "$dev" | grep -q ID_INPUT_JOYSTICK=1; then
      continue
    fi

    local name=$(cat "/sys$(udevadm info -q path $dev)/device/name")

    if [[ "${1:-}" && "$name" != "$1" ]]; then
      continue
    fi

    if [[ ! "$joys" =~ (:|^)$dev(:|$) ]]; then
      joys="${joys:+$joys:}$dev"
    fi
  done

  printf "joys=$joys\n"
}

# Sets the `SDL_JOYSTICK_DEVICE` env variable.
# Takes an optional file name. If provided, first tries to read controller names
# from this file.
# Then iterates through each /dev/input/event* entry in order.
sort_sdl_joysticks() {
  if [[ "${1:-}" && -f "$1" ]]; then
    joys=$(
    sed -e 's/#.*$//' -e '/^\s*$/d' "$1" | \
    while read -r line
    do
      find_sdl_joysticks_with_name "$line"
    done \
    | sed -n 's/^joys=\(.*\)$/\1/p' | tail -1)
  fi

  joys=$(find_sdl_joysticks_with_name | sed -n 's/^joys=\(.*\)/\1/p')

  if [[ "${joys:-}" ]]; then
    export SDL_JOYSTICK_DEVICE="$joys"
  fi
}

/bin/rm -f /tmp/core.*

env

/usr/libexec/bluetooth/bluetoothd --compat --experimental -n --noplugin=avrcp &
sleep 1
hciconfig hci0 down
hciconfig hci0 up

usb_mounts=$(df -P | awk '{print $1 " " $6}' | egrep -o '/media/usb[0-9]')

for mnt in $usb_mounts
do
  echo "searching RetroFE in $mnt"

  if [ -f "$mnt/RETROFE_PATH" ]; then
    retrofe_path="$(cat $mnt/RETROFE_PATH)"
    break
  fi

  if [ -f "$mnt/retrofe/settings.conf" ]; then
    retrofe_path=retrofe
    break
  elif [ -f "$mnt/content/retrofe/settings.conf" ]; then
    retrofe_path="content/retrofe"
    break
  else
    # the content folder is likely inside another folder
    filepath="$(ls $mnt/*/content/retrofe/settings.conf | head -1)"
    regex="$mnt/(.*)/content/retrofe/settings.conf"

    if [[ "$filepath" =~ $regex ]]; then
      folder="${BASH_REMATCH[1]}"
      mv "$mnt/$folder/content" "$mnt/"
      retrofe_path="content/retrofe"
      break
    fi
  fi
done

if [ -z $retrofe_path ]; then
  echo "RetroFE installation not found."
  exit 1
fi

export MODEL=$(tr -d '\0' < /proc/device-tree/model)
echo Model: $MODEL
case "$MODEL" in
  HA8819|HA8818|HA2818|HA2819)
	  export PLATFORM=rk3399
	  ;;
  *)
	  export PLATFORM=rk3328
	  ;;
esac

export MOUNT_POINT=$mnt
export RETROFE_PATH="$MOUNT_POINT/$retrofe_path"
export UCE_PATH=/tmp/retrofe
export SDL_GAMECONTROLLERCONFIG_FILE="$RETROFE_PATH/gamecontrollerdb.txt"
export PATH=$PATH:$UCE_PATH/bin/$PLATFORM:$UCE_PATH/bin
export LD_LIBRARY_PATH=$UCE_PATH/lib32/$PLATFORM:$UCE_PATH/lib32
export LIBRETRO_CORES_PATH="$UCE_PATH/cores/$PLATFORM"
export LIBRETRO_CORES32_PATH="$UCE_PATH/cores32/$PLATFORM"
if [ $MODEL != HA8819 ] && [ $MODEL != HA8818 ]; then
  export AUDIODEV="hw:2,0"
fi
case "$QT_QPA_EGLFS_ROTATION" in
  -90)
    export SDL_VIDEO_ROCKCHIP_ROTATION=1
    ;;
  90)
    export SDL_VIDEO_ROCKCHIP_ROTATION=3
    ;;
  180)
    export SDL_VIDEO_ROCKCHIP_ROTATION=2
    ;;
  *)
    export -n SDL_VIDEO_ROCKCHIP_ROTATION
    ;;
esac

/bin/umount $UCE_PATH
rm -rf $UCE_PATH
mkdir $UCE_PATH
/bin/mount "$RETROFE_PATH/data.squashfs" $UCE_PATH
/bin/mount -o remount,exec $MOUNT_POINT

if [ $MODEL = HA8819 ]; then
  $UCE_PATH/bin/alp_combine_controls.sh
  evsieve_pidfile=/var/run/evsieve_alp_combine_controls.pid
  if [ -f $evsieve_pidfile ]; then
    stock_cp=$(head -2 $evsieve_pidfile | tail -1)
    arcade_cp=$(tail -1 $evsieve_pidfile)
    export SDL_JOYSTICK_DEVICE_BLACKLIST="$stock_cp;$arcade_cp;"
  fi
fi

list_sdl_joysticks
sort_sdl_joysticks "$RETROFE_PATH/gamecontrollerpref.txt"

echo "Found RetroFE at $RETROFE_PATH"
env

ln -sf $UCE_PATH/lib32/ld-linux-armhf.so.3 /tmp

logfile=/dev/null
if [ -f "$MOUNT_POINT/RETROFE_LOG" ]; then
  logfile="$MOUNT_POINT/retrofe.log"
fi

# /bin/rm -rf /download/log_dir/* /download/log_queue_dir/* /download/log_uploading_dir/*

killall -9 bitlcd
$UCE_PATH/bin/bitlcd -server &
sleep 1

echo 1 > /sys/class/graphics/fb0/blank
echo 0 > /sys/class/graphics/fb0/blank

echo "RetroFE started at `date`" > $logfile
$UCE_PATH/bin/retrofe32 >> $logfile 2>&1

/usr/bin/killall -9 bitlcd
/bin/sync

if [ $MODEL = HA8819 ]; then
  /usr/bin/killall evsieve
  /bin/rm -f $evsieve_pidfile
  export -n SDL_JOYSTICK_DEVICE_BLACKLIST
fi

/bin/umount $UCE_PATH

